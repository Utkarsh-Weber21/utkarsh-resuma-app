
const allowedOrigins = [
    'http://localhost:5173',
    'http://localhost:4200',
    'https://khushi-blogging-app.netlify.app'

];

module.exports = allowedOrigins;
