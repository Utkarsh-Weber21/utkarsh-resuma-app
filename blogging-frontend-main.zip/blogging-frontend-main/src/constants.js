

export const IS_AUTHENTICATED = false;